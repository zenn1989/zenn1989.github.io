library("prophet")

# fit prophet model
mod.catch <- prophet(catch, growth = "logistic", yearly.seasonality = TRUE)
# make prediction frame and predict to 360 days forward
fc.catch.frame <- make_future_dataframe(mod.catch, periods = 360)
fc.catch.frame$cap <- 150 # upper lim
fc.catch.frame$floor <- 0 # lower lim
# fit prediction
fc.catch.predict <- predict(mod.catch, fc.catch.frame, mcmc.samples = 100)

# review trend, weekly & yearly seasonality
prophet_plot_components(mod.catch, fc.catch.predict)

# plot observed VS fitted
plot(mod.catch, fc.catch.predict)