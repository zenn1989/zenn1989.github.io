##########################################
### Short-term time-series forecasting ###
### using fb-prophet library           ###
##########################################

# load required libraries
library("DBI")
library("RMariaDB")
library("dplyr")

# sprat = 6, anchovy = 7, see ffcms_ssd_fishes table
fish.id <- 6
action.trawlid <- 32

# establish connection
con <- DBI::dbConnect(RMariaDB::MariaDB(), host = "91.230.138.253", port="20010", user = "azniirkh_reader", password = "ksiw92An&na3", dbname="azniirkh_bio")
# dbListTables(con)
# fishes <- dbReadTable(con, "ffcms_ssd_fishes")

### select sum(amount) as samount, sum(action_time) as stime, count(distinct(ffcms_ssd_catches.ship_id)) as ship_count, `fish_id`, `ffcms_ssd_catches`.`date` from `ffcms_ssd_catches` left join `ffcms_ssd_times` on `ffcms_ssd_catches`.`ship_id` = `ffcms_ssd_times`.`ship_id` and `ffcms_ssd_catches`.`date` = `ffcms_ssd_times`.`date` where `ffcms_ssd_times`.`action_id` = ? group by `ffcms_ssd_catches`.`date`, `ffcms_ssd_catches`.`fish_id`

query <- dbGetQuery(con, "SELECT sum(amount) as catch, sum(action_time) as trawltime, 
                    count(distinct(ffcms_ssd_catches.ship_id)) as ship_count, 
                    `fish_id`, `ffcms_ssd_catches`.`date` from `ffcms_ssd_catches` 
                    LEFT JOIN `ffcms_ssd_times` on `ffcms_ssd_catches`.`ship_id` = `ffcms_ssd_times`.`ship_id` 
                    AND `ffcms_ssd_catches`.`date` = `ffcms_ssd_times`.`date` 
                    WHERE `ffcms_ssd_times`.`action_id` = 32
                    AND `ffcms_ssd_catches`.`fish_id` = 6 
                    GROUP BY `ffcms_ssd_catches`.`date`, 
                    `ffcms_ssd_catches`.`ship_id`,
                    `ffcms_ssd_catches`.`fish_id`")

# process query
query$cpue <- query$catch / (query$trawltime * query$ship_count)

# close db connection
dbDisconnect(con)

catch <- query %>%
  select(catch, date) %>%
  rename(ds = date, y = catch)

catch$cap <- 150
catch$floor <- 0


cpue <- query %>%
  select(cpue, date) %>%
  rename(ds = date, y = cpue)

